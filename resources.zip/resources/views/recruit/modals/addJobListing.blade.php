<div class="modal fade" id="addJoblistingModal" aria-labelledby="examplePositionSidebar" role="dialog" tabindex="-1" aria-hidden="true" style="display: none;">
  <div class="modal-dialog modal-sidebar modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title">List Job</h4>
      </div>
      <div class="modal-body">
         <div class="form-group">
                        <label class="example-title" for="taxable">Taxable</label>
                        
                        <select required="" name="taxable" style="width:100%;" id="taxable" class="form-control " >
                          <option selected value='0'>No</option>
                          <option selected value='1'>Yes</option></select>
                      </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary btn-block waves-effect">Save changes</button>
        <button type="button" class="btn btn-default btn-block btn-pure waves-effect" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>