<?php
namespace App\Traits;
use Illuminate\Http\Request;

trait Recruit
{
	public function FunctionName($value='')
	{
		# code...
	}
}