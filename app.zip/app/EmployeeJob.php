<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeJob extends Model
{
    //
    protected $table='employee_job';
}
