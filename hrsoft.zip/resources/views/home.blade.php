@extends('layouts.master')
@section('stylesheets')

<link rel="stylesheet" href="{{ asset('global/vendor/datatables-bootstrap/dataTables.bootstrap.css') }}">
<style type="text/css">
  a.list-group-item:hover {
    text-decoration: none;
    background-color: #3f51b5;
}
</style>
@endsection
@section('content')
<div class="page ">
    <div class="page-header">
      <h1 class="page-title">Dashboard</h1>
      
      <div class="page-header-actions">
    <div class="row no-space w-250 hidden-sm-down">

      <div class="col-sm-6 col-xs-12">
        <div class="counter">
          <span class="counter-number font-weight-medium">{{date("F j, Y")}}</span>

        </div>
      </div>
      <div class="col-sm-6 col-xs-12">
        <div class="counter">
          <span class="counter-number font-weight-medium" id="time">{{date('h:i s a')}}</span>

        </div>
      </div>
    </div>
  </div>
    </div>
    <div class="page-content container-fluid">
      <div class="row" data-plugin="matchHeight" data-by-row="true">
        <div class="col-xl-3 col-md-6">
          <!-- Widget Linearea One-->
          <a href="#" onclick="showUsers();" >
          <div class="card card-shadow " id="widgetLineareaOne">
            <div class="card-block p-20 p-t-10 bg-orange-900">
              <div class="clearfix">
                <div class="grey-50 pull-xs-left p-y-10">
                  <i class="icon fa fa-users grey-50 font-size-24 vertical-align-bottom m-r-5"></i>                  Employees
                </div>
                <span class="pull-xs-right grey-50 font-size-30">1,253</span>
              </div>
              <div class="m-b-20 grey-50">
                <i class="icon md-long-arrow-up green-500 font-size-16"></i> 15%
                From this last year
              </div>
              
            </div>
          </div>
        </a>
          <!-- End Widget Linearea One -->
        </div>
        <div class="col-xl-3 col-md-6">
          <!-- Widget Linearea Two -->
          <a href="">
          <div class="card card-shadow" id="widgetLineareaTwo">
            <div class="card-block p-20 p-t-10 bg-lime-900">
              <div class="clearfix">
                <div class="grey-50 pull-xs-left p-y-10">
                  <i class="icon md-calendar grey-50 font-size-24 vertical-align-bottom m-r-5"></i>                  Attendance today
                </div>
                <span class="pull-xs-right grey-50 font-size-30">1000 <span class="font-size-16">employees</span></span>
                
              </div>
              <div class="m-b-20 grey-50">
                <i class="icon md-long-arrow-up green-500 font-size-16"></i> 10.2%
                From this yesterday
              </div>
              
            </div>
          </div>
          </a>
          <!-- End Widget Linearea Two -->
        </div>
        <div class="col-xl-3 col-md-6">
          <!-- Widget Linearea Three -->
          <div class="card card-shadow" id="widgetLineareaThree">
            <div class="card-block p-20 p-t-10 bg-teal-900">
              <div class="clearfix">
                <div class="grey-50 pull-xs-left p-y-10">
                  <i class="icon fa fa-list grey-50 font-size-24 vertical-align-bottom m-r-5"></i>                  Total incomplete projects
                </div>
                <span class="pull-xs-right grey-50 font-size-30">18</span>
              </div>
              <div class="m-b-20 grey-50">
                <i class="icon md-long-arrow-down red-500 font-size-16"></i> 15%
                From last quarter
              </div>
              
            </div>
          </div>
          <!-- End Widget Linearea Three -->
        </div>
        <div class="col-xl-3 col-md-6">
          <!-- Widget Linearea Four -->
          <a href="#" onclick="showRequests();" >
          <div class="card card-shadow" id="widgetLineareaFour">
            <div class="card-block p-20 p-t-10 bg-purple-900">
              <div class="clearfix">
                <div class="grey-50 pull-xs-left p-y-10">
                  <i class="icon fa fa-question-circle grey-50 font-size-30 vertical-align-bottom m-r-5"></i>                  <span class="font-size-18">Pending Requests</span>
                </div>
                <span class="pull-xs-right grey-50 font-size-30">12</span>
              </div>
              <div class="m-b-20 grey-50">
                waiting to be approved 
                
              </div>
              
            </div>
          </div>
          </a>
          <!-- End Widget Linearea Four -->
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="card card-shadow" style="padding:0 0 5px 0; ">
          @if(Auth::user()->role->id==0)
              @else
          <div class="ribbon ribbon-clip ribbon-success" >
                                <span id="clocking" style="z-index:999999999; cursor:pointer;" class="ribbon-inner">{{__('Clock In')}}</span>
                              </div>
            <div  class="ribbon ribbon-clip ribbon-reverse ribbon-danger" >
                                <span class="ribbon-inner" id="clockout" style="z-index:999999999; cursor:pointer;">{{__('Clock Out')}}</span>
                              </div>
                    @endif
            <div class="card-block text-xs-center bg-white p-40">
             
            <div id="clockin"  >
            
            
            </div><br><br> 
            
             </div>
          </div>
        </div>
        <div class="col-lg-8 col-xs-12 masonry-item">
          <!-- Panel Projects Status -->
          <div class="panel">
            <div class="panel-heading">
              <h3 class="panel-title">
                Vacant Positions
                <span class="tag tag-pill tag-info">6</span>
              </h3>
              <div class="panel-actions panel-actions-keep">
                <a href="#" class="btn btn-info"> View All Vacancies</a>
                
              </div>
            </div>
            <div class="panel-body">
              <div class="table-responsive">
              <table class="table table-striped dataTable" id="vacancytable">
                <thead>
                  <tr>
                    <td>S/N</td>
                    <td>Position</td>
                    <td>Department</td>
                    <td>Priority</td>
                    <td>Vacant since</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>Application Developer</td>
                    <td>IT</td>
                    <td>
                      <span class="tag tag-danger">Urgent</span>
                    </td>

                    <td>1 day ago</td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>Business Development Officer</td>
                    <td>Sales and Marketing</td>
                    <td>
                      <span class="tag tag-danger">Urgent</span>
                    </td>
                     <td>2 weeks ago</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>Executive Assistant</td>
                    <td>Admin</td>
                    <td>
                      <span class="tag tag-warning">Not Urgent</span>
                    </td>
                     <td>1 week ago</td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>Sales Executive</td>
                    <td>Sales and Marketing</td>
                    <td>
                      <span class="tag tag-danger">Urgent</span>
                    </td>
                     <td>3 weeks ago</td>
                  </tr>
                  <tr>
                    <td>5</td>
                    <td>Driver</td>
                    <td>Admin</td>
                    <td>
                      <span class="tag tag-danger">Urgent</span>
                    </td>
                     <td>2 weeks ago</td>
                  </tr>
                </tbody>
              </table>
                </div>  
            </div>
            <div class="panel-footer">
                
            </div>
            
          </div>
          <!-- End Panel Projects Stats -->
        </div>
          
      </div>
  </div>
  </div>
  <!-- Site Action -->
<div class="modal fade in modal-3d-flip-horizontal modal-info" id="requestsModal" aria-hidden="true" aria-labelledby="requestsModal" role="dialog" tabindex="-1">
      <div class="modal-dialog ">
          <div class="modal-content">        
          <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title" >Pending Requests</h4>
          </div>
            <div class="modal-body">         
              <div class="col-xs-12 "> 
                <div class="list-group list-group-gap">
                  <a class="list-group-item list-group-item-warning" href="javascript:void(0)">
                    <h4 class="list-group-item-heading grey-50">Leave Requests</h4>
                    <p class="list-group-item-text grey-50">5 requests</p>
                  </a>
                  <a class="list-group-item list-group-item-success" href="javascript:void(0)">
                    <h4 class="list-group-item-heading grey-50">Profile Change Requests</h4>
                    <p class="list-group-item-text grey-50">2 requests</p>
                  </a>
                  <a class="list-group-item list-group-item-info" href="javascript:void(0)">
                    <h4 class="list-group-item-heading grey-50">Expenses Requests</h4>
                    <p class="list-group-item-text grey-50">5 requests</p>
                  </a>
                </div>
               </div>        
            </div>
            <div class="modal-footer">
             </div>
         </div>
        
      </div>
    </div>
    <div class="modal fade in modal-3d-flip-horizontal modal-info" id="usersModal" aria-hidden="true" aria-labelledby="requestsModal" role="dialog" tabindex="-1">
      <div class="modal-dialog ">
          <div class="modal-content">        
          <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title" >All Users</h4>
          </div>
            <div class="modal-body">         
              <div class="col-xs-12 "> 
                @php
                  $arrX = ['red-900','pink-900','deep-orange-900','teal-900','lime-900','cyan-900','blue-900','purple-900','deep-purple-900','light-blue-900','amber-900','yellow-900','orange-900','blue-grey-900','brown-900'];   
                @endphp
                <div class="list-group list-group-gap">
                  @foreach($companies as $company)
                  @php
                    $randIndex = array_rand($arrX);
                  @endphp
                  <a class="list-group-item bg-{{$arrX[$randIndex]}}" href="javascript:void(0)">
                    <h4 class="list-group-item-heading grey-50">{{$company->name}}</h4>
                    <p class="list-group-item-text grey-50">{{mt_rand(100,900)}} employees</p>
                  </a>
                  @endforeach
                  
                </div>
               </div>        
            </div>
            <div class="modal-footer">
             </div>
         </div>
        
      </div>
    </div>
  
  <!-- End Add User Form -->

@section('scripts')
  <script src="{{ asset('global/vendor/datatables/jquery.dataTables.js') }}"></script>
  <script src="{{ asset('global/vendor/datatables-fixedheader/dataTables.fixedHeader.js') }}"></script>
  <script src="{{ asset('global/vendor/datatables-bootstrap/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#vacancytable').DataTable( {
        "paging":   false,
        "searching": false,
        "info":     false
    } );
} );

  function showRequests() {
    $('#requestsModal').modal();
  }
  function showUsers() {
    $('#usersModal').modal();
  }
</script>
@endsection