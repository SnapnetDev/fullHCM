<div class="site-menubar">
    <div class="site-menubar-body">
      <div>
        <div>
          <ul class="site-menu" data-plugin="menu">
            <li class="site-menu-item ">
              <a href="{{ route('home') }}" dropdown-tag="false">
                <i class="site-menu-icon md-home" aria-hidden="true"></i>
                <span class="site-menu-title">Home</span>
                <span class="site-menu-arrow"></span>
              </a>
            </li>
            <li class="site-menu-item has-sub ">
              <a href="javascript:void(0)" dropdown-tag="false">
                <i class="site-menu-icon fa fa-area-chart" aria-hidden="true"></i>
                <span class="site-menu-title">People Analytics</span>
                <span class="site-menu-arrow"></span>
              </a>
              <ul class="site-menu-sub">
                <li class="site-menu-item ">
                  <a class="animsition-link" href="{{route('executive_view')}}">
                    <span class="site-menu-title">HR</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="{{route('executive_view_finance')}}">
                    <span class="site-menu-title">Finance</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="{{route('executive_view_second')}}">
                    <span class="site-menu-title">Others</span>
                  </a>
                </li>
              </ul>
            </li>
            
            
            
            <li class="site-menu-item has-sub ">
              <a href="javascript:void(0)" dropdown-tag="false">
                <i class="site-menu-icon fa fa-sitemap" aria-hidden="true"></i>
                <span class="site-menu-title">Self Service</span>
                <span class="site-menu-arrow"></span>
              </a>
              <ul class="site-menu-sub">
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">My attendance</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Leave Requests
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Loan Requests </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Travel Request </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">View payslip </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">My Expenses </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Job Openings </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Health </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">My Documents </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Pay Utility Bills </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Snap Loan </span>
                  </a>
                </li>
              </ul>
            </li>
            <li class="site-menu-item ">
              <a href="{{route('executive_view')}}" dropdown-tag="false">
                <i class="site-menu-icon fa fa-list" aria-hidden="true"></i>
                <span class="site-menu-title">Project Management</span>
                <span class="site-menu-arrow"></span>
              </a>
            </li>
            <li class="site-menu-item ">
              <a href="{{route('executive_view')}}" dropdown-tag="false">
                <i class="site-menu-icon fa fa-user-plus" aria-hidden="true"></i>
                <span class="site-menu-title">Recruit</span>
                <span class="site-menu-arrow"></span>
              </a>
            </li>
            <li class="site-menu-item has-sub ">
              <a href="javascript:void(0)" dropdown-tag="false">
                <i class="site-menu-icon md-calendar-check" aria-hidden="true"></i>
                <span class="site-menu-title">Core Adminsitrative HR</span>
                <span class="site-menu-arrow"></span>
              </a>
              <ul class="site-menu-sub">
                <li class="site-menu-item ">
                  <a class="animsition-link" href="{{url('users')}}">
                    <span class="site-menu-title">Manage Employee</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Attendance 360</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Succession Planning</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Employee Health</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Surveys</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">All Documents</span>
                  </a>
                </li>
              </ul>
            </li>
            <li class="site-menu-item has-sub ">
              <a href="javascript:void(0)" dropdown-tag="false">
                <i class="site-menu-icon fa fa-mortar-board" aria-hidden="true"></i>
                <span class="site-menu-title">Training and Development</span>
                <span class="site-menu-arrow"></span>
              </a>
              <ul class="site-menu-sub">
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Recommended Traning</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Select Elective Training</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Training Status </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Traning Schedule for Fiscal Year </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Traning Surveys </span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">Enrolled Training Status </span>
                  </a>
                </li>
              </ul>
            </li>
            <li class="site-menu-item ">
              <a href="{{url('settings')}}" dropdown-tag="false">
                <i class="site-menu-icon fa fa-money" aria-hidden="true"></i>
                <span class="site-menu-title">Compensation and Benefits</span>
                <span class="site-menu-arrow"></span>
              </a>
            </li>
            <li class="site-menu-item has-sub ">
              <a href="javascript:void(0)" dropdown-tag="false">
                <i class="site-menu-icon fa fa-area-chart" aria-hidden="true"></i>
                <span class="site-menu-title">Performance Management</span>
                <span class="site-menu-arrow"></span>
              </a>
              <ul class="site-menu-sub">
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">All Document Records</span>
                  </a>
                </li>
                <li class="site-menu-item ">
                  <a class="animsition-link" href="../../apps/contacts/contacts.html">
                    <span class="site-menu-title">My Documents</span>
                  </a>
                </li>
              </ul>
            </li>
          <li class="site-menu-item ">
              <a href="{{url('settings')}}" dropdown-tag="false">
                <i class="site-menu-icon md-settings" aria-hidden="true"></i>
                <span class="site-menu-title">Settings</span>
                <span class="site-menu-arrow"></span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>