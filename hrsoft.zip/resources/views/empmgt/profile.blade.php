@extends('layouts.master')
@section('stylesheets')
  <link rel="stylesheet" href="{{ asset('global/vendor/bootstrap-datepicker/bootstrap-datepicker.css') }}">

  <link rel="stylesheet" href="{{ asset('global/vendor/bootstrap-table/bootstrap-table.css') }}">
  <style type="text/css">
  	.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    width: 50%;
    text-align: center;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
    background: #333;
}


  </style>
@endsection
@section('content')
<div class="page">
    <div class="page-header">
      <h1 class="page-title">User Profile</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../index.html">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">Employee Management</a></li>
        <li class="breadcrumb-item active">User Profile</li>
      </ol>
      <div class="page-header-actions">
        <button type="button" id="datasave" class="btn  btn-primary"  >
          Save
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-primary btn-round" data-toggle="tooltip"
        data-original-title="Refresh">
          <i class="icon md-refresh-alt" aria-hidden="true"></i>
        </button>
        <button type="button" class="btn btn-sm btn-icon btn-primary btn-round" data-toggle="tooltip"
        data-original-title="Setting">
          <i class="icon md-settings" aria-hidden="true"></i>
        </button>
      </div>
    </div>
    <div class="page-content container-fluid">
      <div class="row">
        <div class="col-md-12 col-xs-12">
        	<!-- Panel -->
          <div class="panel">
            <div class="panel-body nav-tabs-animate nav-tabs-horizontal" data-plugin="tabs">
              <ul class="nav nav-tabs nav-tabs-line" role="tablist">
                <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#personal"
                  aria-controls="activities" role="tab">Personal Information </a></li>
                <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#academics" aria-controls="profile"
                  role="tab">Academic History</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#dependants" aria-controls="messages"
                  role="tab">Dependants</a></li>
                  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#skills" aria-controls="messages"
                  role="tab">Skills</a></li>
                  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#experience" aria-controls="messages"
                  role="tab">Work Experience</a></li>
                  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#history" aria-controls="messages"
                  role="tab">Promotion History</a></li>
                
              </ul>
              <div class="tab-content">
                <div class="tab-pane active animation-slide-left" id="personal" role="tabpanel">
                	<br>
                  <form enctype="multipart/form-data" id="emp-data" method="POST" onsubmit="">
                  	@csrf
                  	<input type="hidden" name="user_id" value="{{$user->id}}">
                  	<div class="row">
                  	<div class="col-md-4 col-lg-4">
                  		<div class="form-group">
					        <label>Upload Image</label>
					        <img class="img-circle img-bordered img-bordered-blue text-center" width="150" height="150" src="{{ asset('global/portraits/2.jpg') }}" alt="..." id='img-upload'>
					      
					        <div class="input-group">
					            <span class="input-group-btn">
					                <span class="btn btn-default btn-file">
					                    Browse… <input type="file" id="imgInp" name="avatar" accept="image/*">
					                </span>
					            </span>
					            <input type="text" class="form-control" readonly>
					        </div>
					    </div>
                  		
                  			
                  		
                  		
                  	</div>

                  	<br>
                  	<div class="col-md-4">
              		<div class="form-group form-material" data-plugin="formMaterial">
	                  <label class="form-control-label" for="inputText">Name</label>
	                  <input type="text" class="form-control" id="name" value="{{$user->name}}" name="name" placeholder="Name"
	                   required />
	                </div>
                  	</div>
                  	<div class="col-md-4">
              		<div class="form-group form-material" data-plugin="formMaterial">
	                  <label class="form-control-label" for="inputText">Employee Number </label>
	                  <input type="text" class="form-control" id="emp_num" value="{{$user->emp_num}}" name="emp_num" placeholder="Employee Number"
	                   required />
	                </div>
                  	</div>
                  	<div class="col-md-4">
                  		<div class="form-group form-material" data-plugin="formMaterial">
	                  <label class="form-control-label" for="inputText">Email</label>
	                  <input type="email" class="form-control" id="email" value="{{$user->email}}" name="email" placeholder="Email"
	                   required />
	                </div>

                  	</div>
                  	<div class="col-md-4">
                  		<div class="form-group form-material" data-plugin="formMaterial">
	                  <label class="form-control-label" for="inputText">Phone Number</label>
	                  <input type="text" class="form-control" id="phone" value="{{$user->phone_num}}" name="phone" placeholder="Phone Number" required 
	                  />
	                </div>

                  	</div>
                  </div>

                  	<hr>
                  	<div class="row">
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Sex</label>
		                  <select class="form-control" id="sex" name="sex">
		                    <option>Male</option>
		                    <option>Female</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Marital Status</label>
		                  <select class="form-control" id="marital_status" name="marital_status">
		                    <option>Single</option>
		                    <option>Married</option>
		                    <option>Divorced</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Date of Birth</label>
			                  <input type="text" class="form-control datepicker"  id="dob" name="dob" placeholder="Phone Number"
			                   required  value="{{date("m/d/Y",strtotime($user->dob))}}" />
			                </div>
                  		</div>
                  	</div>
                  	<div class="row">
                  		<div class="col-md-12">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                   <label class="form-control-label" for="inputText">Address</label>
	                   <textarea class="form-control" id="address" name="address" rows="3"></textarea>
		                </div>
                  		</div>
                  		
                  	</div>
                  	<div class="row">
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Country</label>
		                  <select class="form-control" id="country" name="country">
		                    <option>Country1</option>
		                    <option>Country2</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">State/Region</label>
		                  <select class="form-control" id="state" name="state">
		                    <option>State1</option>
		                    <option>State2</option>
		                    <option>State3</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">LGA/ District</label>
		                  <select class="form-control" id="lga" name="lga">
		                    <option>LGA1</option>
		                    <option>LGA2</option>
		                    <option>LGA3</option>
		                  </select>
		                </div>
                  		</div>
                  		
                  	</div>
                  
                  	<div class="row">
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Company</label>
		                  <select class="form-control" id="company_id" name="company_id">
		                    <option>Company 1</option>
		                    <option>Company 2</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Branch</label>
		                  <select class="form-control" id="branch_id" name="branch_id">
		                    <option>Branch 1</option>
		                    <option>Branch 2</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Department</label>
		                  <select class="form-control" id="dept_id" name="dept_id">
		                    <option>Company 1</option>
		                    <option>Company 2</option>
		                  </select>
		                </div>
                  		</div>
                  		
                  		
                  	</div>
                  		<div class="row">
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Hire Date</label>
			                  <input type="text" class="form-control datepicker"  id="hiredate" name="hiredate" placeholder="Hire Date"
			                  />
			                </div>
                  		</div>
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Job Role</label>
		                  <select class="form-control" id="job_id" name="job_id">
		                    <option>Branch 1</option>
		                    <option>Branch 2</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Grade</label>
		                  <input type="text" class="form-control " disabled  id="inputText" name="inputText" placeholder="Grade 14" 
			                  />
		                </div>
                  		</div>
                  		
                  		
                  	</div>
                  	<div class="row">
                  		<h4 style="padding-left: 15px;">Account Details</h4>
                  		
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Bank</label>
		                  <select class="form-control" id="bank_id" name="bank_id">
		                    <option>Bank A</option>
		                    <option>Bank B</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Account Number</label>
			                  <input type="text" class="form-control "  id="account_no" name="account_no" placeholder="Account Number"
			                  />
			                </div>
                  		</div>
                  		
                  		
                  		
                  	</div>
                  	<div class="row">
                  		<h4 style="padding-left: 15px;">Next of Kin</h4>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Name</label>
			                  <input type="text" class="form-control "  id="nok_name" name="nok_name" placeholder="Name"
			                  />
			                </div>
                  		</div>
                  		<div class="col-md-4">
              			<div class="form-group form-material" data-plugin="formMaterial">
		                  <label class="form-control-label" for="select">Relationship</label>
		                  <select class="form-control" id="nok_relationship" name="nok_relationship">
		                    <option>Father</option>
		                    <option>Mother</option>
		                  </select>
		                </div>
                  		</div>
                  		<div class="col-md-4">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Phone Number</label>
			                  <input type="text" class="form-control "  id="nok_phone" name="nok_phone" placeholder="Phone Number"
			                  />
			                </div>
                  		</div>
                  		<div class="col-md-12">
                  			<div class="form-group form-material" data-plugin="formMaterial">
			                  <label class="form-control-label" for="inputText">Address of Next of Kin</label>
			                  <textarea class="form-control" id="nok_address" name="nok_address" rows="3"></textarea>
			                </div>
                  		</div>
                  		
                  		
                  		
                  	</div>
                  	<br>
                  	<button type="submit" class="btn btn-primary btn-lg">Save</button>
                  </form>
                  
                </div>
                <div class="tab-pane animation-slide-left" id="academics" role="tabpanel">
                	<br>
                	<button class="btn btn-primary ">Add Qualification</button>
                  <table id="exampleTablePagination" data-toggle="table" 
                  data-query-params="queryParams" data-mobile-responsive="true"
                  data-height="400" data-pagination="true" data-search="true" class="table table-striped">
                    <thead>
                      <tr>
                        <th >Qualification:</th>
                        <th >Year:</th>
                        <th >Institution:</th>
                        <th >CGPA/ Grad / Score:</th>
                        <th >Discipline:</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	@forelse($user->educationHistories as $history)
                    	<tr>
                    		<td>{{$history->qualification}}</td>
                    		<td>{{date('Y',strtotime($history->year))}}</td>
                    		<td>{{$history->institution}}</td>
                    		<td>{{$history->grade}}</td>
                    		<td>{{$history->course}}</td>
                    		<td></td>
                    	</tr>
                    	@empty
                    	@endforelse
                    	
                    </tbody>
                  </table>
                </div>
                <div class="tab-pane animation-slide-left" id="dependants" role="tabpanel">
                	<br>
                	<button class="btn btn-primary ">Add Dependant</button>
                  <table id="exampleTablePagination" data-toggle="table" 
                  data-query-params="queryParams" data-mobile-responsive="true"
                  data-height="400" data-pagination="true" data-search="true" class="table table-striped">
                    <thead>
                      <tr>
                        <th >Name:</th>
                        <th >Date of Birth:</th>
                        <th >Email:</th>
                        <th >Phone Number:</th>
                        <th >Relationship:</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	@forelse($user->dependants as $dependant)
                    	<tr>
                    		<td>{{$dependant->name}}</td>
                    		<td>{{date("F j, Y", strtotime($dependant->dob))}}</td>
                    		<td>{{$dependant->email}}</td>
                    		<td>{{$dependant->phone_num}}</td>
                    		<td>{{$dependant->relationship}}</td>
                    		<td></td>
                    	</tr>
                    	@empty
                    	@endforelse
                    	
                    </tbody>
                  </table>
                </div>
                <div class="tab-pane animation-slide-left" id="skills" role="tabpanel">
                	<br>
                	<button class="btn btn-primary ">Add Skill</button>
                  <table id="exampleTablePagination" data-toggle="table" 
                  data-query-params="queryParams" data-mobile-responsive="true"
                  data-height="400" data-pagination="true" data-search="true" class="table table-striped">
                    <thead>
                      <tr>
                        <th >Skill:</th>
                        <th >Experience (Years):</th>
                        <th >Rating:</th>
                        <th >Remarks:</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	@forelse($user->skills as $skill)
                    	<tr>
                    		<td>{{$skill->skill}}</td>
                    		<td>{{$skill->experience}}</td>
                    		<td>{{$skill->rating}}</td>
                    		<td>{{$skill->remark}}</td>
                    		<td></td>
                    	</tr>
                    	@empty
                    	@endforelse
                    	
                    </tbody>
                  </table>
                </div>
                <div class="tab-pane animation-slide-left" id="experience" role="tabpanel">
                	<br>
                	<button class="btn btn-primary ">Add Employment History</button>
                  <table id="exampleTablePagination" data-toggle="table" 
                  data-query-params="queryParams" data-mobile-responsive="true"
                  data-height="400" data-pagination="true" data-search="true" class="table table-striped">
                    <thead>
                      <tr>
                        <th >Organization:</th>
                        <th >Position:</th>
                        <th >Start Date:</th>
                        <th >End Date:</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	@forelse($user->employmentHistories as $ehistory)
                    	<tr>
                    		<td>{{$ehistory->organization}}</td>
                    		<td>{{$ehistory->position}}</td>
                    		<td>{{date("F j, Y", strtotime($ehistory->start_date))}}</td>
                    		<td>{{date("F j, Y", strtotime($ehistory->end_date))}}</td>
                    		<td></td>
                    	</tr>
                    	@empty
                    	@endforelse
                    	
                    </tbody>
                  </table>
                </div>
                <div class="tab-pane animation-slide-left" id="history" role="tabpanel">
                  <table id="exampleTablePagination" data-toggle="table" 
                  data-query-params="queryParams" data-mobile-responsive="true"
                  data-height="400" data-pagination="true" data-search="true" class="table table-striped">
                    <thead>
                      <tr>
                        <th >Organization:</th>
                        <th >Position:</th>
                        <th >Start Date:</th>
                        <th >End Date:</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	@forelse($user->employmentHistories as $ehistory)
                    	<tr>
                    		<td>{{$ehistory->organization}}</td>
                    		<td>{{$ehistory->position}}</td>
                    		<td>{{date("F j, Y", strtotime($ehistory->start_date))}}</td>
                    		<td>{{date("F j, Y", strtotime($ehistory->end_date))}}</td>
                    		<td></td>
                    	</tr>
                    	@empty
                    	@endforelse
                    	
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!-- End Panel -->

          
        </div>
        
      </div>
    </div>
  </div>
@endsection
@section('scripts')
	<script src="{{asset('global/vendor/bootstrap-datepicker/bootstrap-datepicker.js')}}"></script>
  <script src="{{asset('global/js/Plugin/bootstrap-datepicker.js')}}"></script>

  <script src="{{asset('global/vendor/bootstrap-table/bootstrap-table.min.js')}}"></script>
  <script src="{{asset('global/vendor/bootstrap-table/extensions/mobile/bootstrap-table-mobile.js')}}"></script>
  <script src="{{asset("js/countries.js")}}"></script>
   <script language="javascript">
            populateCountries("country", "state");
        </script>
  <script type="text/javascript">
  	$(document).ready(function() {
  		//date picker initialization
    $('.datepicker').datepicker();
 	//function for picture change
    	$(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
		});

		$('.btn-file :file').on('fileselect', function(event, label) {
		    
		    var input = $(this).parents('.input-group').find(':text'),
		        log = label;
		    
		    if( input.length ) {
		        input.val(log);
		    } else {
		        if( log ) alert(log);
		    }
	    
		});

		function readURL(input) {
		    if (input.files && input.files[0]) {
		        var reader = new FileReader();
		        
		        reader.onload = function (e) {
		            $('#img-upload').attr('src', e.target.result);
		        }
		        
		        reader.readAsDataURL(input.files[0]);
		    }
		}

		$("#imgInp").change(function(){
		    readURL(this);
		}); 


		$(document).on('submit', '#emp-data', function(event) {
			event.preventDefault();
		var form = $(this);
			    var formdata = false;
			    if (window.FormData){
			        formdata = new FormData(form[0]);
			    }
			    // console.log(formdata);
			    // return;
			    //var formAction = form.attr('action');
			    $.ajax({
			        url         : '{{url('users')}}',
			        data        : formdata ? formdata : form.serialize(),
			        cache       : false,
			        contentType : false,
			        processData : false,
			        type        : 'POST',
			        success     : function(data, textStatus, jqXHR){
			            toastr["success"]("Changes saved successfully",'Success');
			        },
			        error:function(data, textStatus, jqXHR){
			           
			            jQuery.each( data['responseJSON'], function( i, val ) {
							 
							  jQuery.each( val, function( i, valchild ) {
							 
							  toastr["error"](valchild[0]);
							  
							});
							  
							});
			             console.log(textStatus);
			              console.log(jqXHR);
			        }
			    });
			    
		});	
		//submit form on button click
		$(document).on('click', '#datasave', function(e) {
			
		// document.getElementById("emp-data");
		var form = document.getElementById("emp-data");
			    var formdata = false;
			    if (window.FormData){
			        formdata = new FormData(form[0]);
			        console.log(formdata);
			    }
			    // console.log(formdata);
			    // return
			    //var formAction = form.attr('action');
			    $.ajax({
			        url         : '{{url('users')}}',
			        data        : formdata ? formdata : form.serialize(),
			        cache       : false,
			        contentType : false,
			        processData : false,
			        type        : 'POST',
			        success     : function(data, textStatus, jqXHR){
			            toastr["success"]("Changes saved successfully",'Success');
			        },
			        error:function(data, textStatus, jqXHR){
			           
			            jQuery.each( data['responseJSON'], function( i, val ) {
							 
							  jQuery.each( val, function( i, valchild ) {
							 
							  toastr["error"](valchild[0]);
							  
							});
							  
							});
                  console.log(data);
			             console.log(textStatus);
			              console.log(jqXHR);
			        }
			    });
		
	});

	});
  </script>
   
@endsection