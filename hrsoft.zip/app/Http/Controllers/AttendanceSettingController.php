<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\WorkingPeriod;
use App\Company;
class AttendanceSettingController extends Controller
{

	public function index()
	{
		$companies=Company::all();
		foreach ($companies as $company) {
			if($company->workingperiod){

			}else{
				$workingperiod=new WorkingPeriod();
				$workingperiod->sob='08:00';
				$workingperiod->cob='17:00';
				$workingperiod->company_id=$company->id;
				$workingperiod->save();
			}
		}
		$workingperiods=WorkingPeriod::all();
		return view('settings.attendancesettings.index',compact('companies','workingperiods'));
	}
	public function saveWorkingPeriod(Request $request)
	{
		WorkingPeriod::updateorCreate(['id'=>$request->working_period_id],['sob'=>$request->sob,'cob'=>$request->cob]);
		return  response()->json('success',200);
	}
	public function getWorkingPeriod($workingperiod_id)
	{
		$workingperiod=WorkingPeriod::find($workingperiod_id);
		return  response()->json($workingperiod,200);
	}
	public function deleteWorkingPeriod($workingperiod_id)
	{
		$workingperiod=WorkingPeriod::find($workingperiod_id);
		if ($workingperiod) {
			$workingperiod->delete();
		}else{
			return  response()->json(['failed'],200);
		}
		return  response()->json(['success'],200);
	}

	public function saveQualification(Request $request)
	{
		Qualification::updateOrCreate(['id'=>$request->qualification_id],['name'=>$request->name]);
		return  response()->json('success',200);
	}
	public function getQualification($qualification_id)
	{
		$qualification=Qualification::find($qualification_id);
		return  response()->json($qualification,200);
	}
	public function deleteQualification($qualification_id)
	{
		$qualification=Qualification::find($qualification_id);
		if ($qualification) {
			$qualification->delete();
		}else{
			return  response()->json(['failed'],200);
		}
		return  response()->json(['success'],200);
	}
	
	

}