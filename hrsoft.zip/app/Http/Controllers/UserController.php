<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Company;
use Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=User::where('superadmin','!=',1)->paginate(10);
        $companies=Company::all();
        $branches=$companies->first()->branches;
        $departments=$companies->first()->departments;
        $usersforcount=User::where('superadmin','!=',1)->get();
        return view('empmgt.list',['users'=>$users,'usersforcount'=>$usersforcount,'companies'=>$companies,'branches'=>$branches,'departments'=>$departments]);
    }
    public function getCompanyDepartmentsBranches($company_id){
        $company=Company::find($company_id);
        return ['departments'=>$company->departments,'branches'=>$company->branches];
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          
       $validator = Validator::make($request->all(), ['name'=>'required|min:3','email' => [
            'required',
            Rule::unique('users')->ignore($request->user_id)
        ],'emp_num'=>['required',
            Rule::unique('users')->ignore($request->user_id)
        ],'phone'=>['required',
            Rule::unique('users')->ignore($request->user_id)
        ]]);

       if ($validator->fails()) {
            return response()->json([
                    $validator->errors()
                    ],401);
        }
          if ($request->file('avatar')) {
                    $path = $request->file('avatar')->store('public');
                    if (Str::contains($path, 'public/')) {
                       $filepath= Str::replaceFirst('public/', '', $path);
                    } else {
                        $filepath= $path;
                    }
                    $document->path = $filepath;
                }
       return $request->all();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //

    }
    public function modal($user_id)
    {
       $user=User::find($user_id);
       return view('empmgt.partials.info',['user'=>$user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($user_id)
    {
       $user=User::find($user_id);
       return view('empmgt.profile',['user'=>$user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }
}
