<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\DailyAttendance;
class AttendanceController extends Controller
{ 

	public function viewAttendanceCalendar($value='')
	{
		return view('xtrafeature.attendance360');
	}
	public function displayCalendar(Request $request)
	{
		try {
			$attendances=DailyAttendance::whereBetween('date',[$request->start,$request->end])->get();
			
			
		$emps=\DB::table('users')
						->join('daily_attendance','users.emp_num','=','daily_attendance.emp_num')
						->select('users.name','daily_attendance.clock_in as startdate')
						->whereBetween('daily_attendance.date',[$request->start,$request->end])
						->get();
		 
			foreach($emps as $empres):
			
			$dispemp[]=['title'=>$empres->name,'start'=>$empres->startdate];
			 
			endforeach;
			if(isset($dispemp)):
			return response()->json($dispemp);
			else:
			$dispemp=['title'=>'Nil','start'=>'2016-09-09'];
			return response()->json($dispemp);
			endif;
			
		}
		
		catch(\Exception $ex){
			
			return response()->json("Error:$ex");
		}
	}
}