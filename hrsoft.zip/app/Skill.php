<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Skill extends Model
{
	protected $table="emp_skills";
    public function user()
    {
        return $this->belongsTo('App\User','emp_id');
    }
}
