<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'password','emp_num','sex','dob','phone','marital_status','password','subsidiary_id','branch_id','job_id','hiredate','role_id','image','remember_token','created_at','updated_at','address','state_of_origin_id','lga_id','employment_status_id','superadmin','bank_id','account_num','locale',];
    protected $dates=['hiredate'];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function role()
    {
        return $this->belongsTo('App\Role');
    }
    public function branch()
    {
        return $this->belongsTo('App\Branch');
    }
    public function department()
    {
        return $this->belongsTo('App\Department');
    }
    public function company()
    {
        return $this->belongsTo('App\Company');
    }
    public function bank()
    {
        return $this->belongsTo('App\Bank');
    }
    public function subsidiary()
    {
        return $this->belongsTo('App\Subsidiary');
    }
    //Nok is the next of kin
    public function nok()
    {
        return $this->hasOne('App\Nok');
    }
    public function job()
    {
        return $this->belongsTo('App\Job');
    }
    public function dependants()
    {
        return $this->hasMany('App\Dependant','emp_id');
    }
    public function employmentHistories()
    {
        return $this->hasMany('App\EmploymentHistory');
    }
    public function promotionHistories()
    {
        return $this->hasMany('App\PromotionHistory');
    }
    public function educationHistories()
    {
        return $this->hasMany('App\EducationHistory','emp_id');
    }
    public function skills()
    {
        return $this->hasMany('App\Skill','emp_id');
    }
    public function profHistories()
    {
        return $this->hasMany('App\ProfHistory');
    }
    public function socialMediaAccounts()
    {
        return $this->belongsToMany('App\SocialMediaAccount','user_social_media_account','user_id','social_media_account_id');
    }
    public function managers()
    {
        return $this->belongsToMany('App\User','employee_manager','user_id','manager_id')->withTimestamps();
    }
    public function employees()
    {
        return $this->belongsToMany('App\User','employee_manager','manager_id','user_id')->withTimestamps();
    }
    public function employmentStatus()
    {
        return $this->belongsTo('App\EmploymentStatus');
    }
    public function grades()
    {
        return $this->hasManyThrough('App\Grade','App\PromotionHistory');
    }
    public function performanceseason(){
         $checkseason= \App\PerformanceSeason::select('season')->value('season');
             return $checkseason;
    }
    public function quarterName($num){
        $formatter = new \NumberFormatter('en_US', \NumberFormatter::SPELLOUT);
        $formatter->setTextAttribute(\NumberFormatter::DEFAULT_RULESET,"%spellout-ordinal");
        return ucfirst($formatter->format($num));
    }
  public function progressreport(){
        return $this->hasMany('App\ProgressReport','emp_id');
    }

public function getquarter(){
    
    //getquarter
    $review=\App\fiscal::where('id',1)->first();
    return 12/$review->end_month;
    
  }
    public function getEmploymentStatusAttribute(){

        return $this->employment_status_id==1 ? 'Locked' : 'Open';
    }

    public function goal(){
        return $this->hasMany('App\Goal','user_id')->withDefault();
    }

     public function getProbationStatusAttribute(){
          if(!is_null($this->hiredate) && $this->hiredate->diffInDays()<=180){
            return '<span class="tag tag-warning">On-Probation</span>';
          }
          elseif(!is_null($this->hiredate) && $this->hiredate->diffInDays()>180 && $this->confirmed==1){
            return '<span class="tag tag-success">Confirmed</span>';
          }
          else{
            return 'N/A';
          }
        }



}
