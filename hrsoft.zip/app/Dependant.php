<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dependant extends Model
{
    protected $table='emp_dependants';

    public function user()
    {
        return $this->belongsTo('App\User','emp_id');
    }
}
