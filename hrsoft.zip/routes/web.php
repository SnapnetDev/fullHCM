<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('empmgt.list');
// });
Route::get('/emp', function () {
    return view('empmgt.partials.info');
});
Route::get('/', function () {
    return redirect(route('home'));;
});

Auth::routes();
//user routes
Route::get('/home', 'HomeController@index')->name('home');

Route::get('users/modal/{user_id}','UserController@modal')->name('users.modal');
Route::resource('users', 'UserController');
Route::get('users/company/departmentsandbranches/{company_id}','UserController@getCompanyDepartmentsBranches')->name('users.companydepartmentsandbranches');
//end user routes
//settings routes
Route::get('/settings', 'GlobalSettingController@index')->name('settings');

Route::get('/settings/companies', 'CompanySettingController@companies')->name('companies');
Route::post('/settings/companies', 'CompanySettingController@saveCompany')->name('companies.store');
Route::get('/settings/companies/{company_id}', 'CompanySettingController@getCompany')->name('companies.show');
Route::get('/settings/companies/parent/{company_id}', 'CompanySettingController@changeParentCompany')->name('companies.parent');

Route::get('/settings/departments/{company_id}', 'CompanySettingController@departments')->name('departments');
Route::post('/settings/departments', 'CompanySettingController@saveDepartment')->name('departments.store');
Route::get('/settings/department/{department_id}', 'CompanySettingController@getDepartment')->name('departments.show');
Route::get('/settings/departments/delete/{department_id}', 'CompanySettingController@deleteDepartment')->name('departments.delete');

Route::get('/settings/branches/{company_id}', 'CompanySettingController@branches')->name('branches');
Route::post('/settings/branches', 'CompanySettingController@saveBranch')->name('branches.store');
Route::get('/settings/branch/{branch_id}', 'CompanySettingController@getBranch')->name('branches.show');

Route::get('/settings/jobs/{company_id}', 'CompanySettingController@jobs')->name('jobs');
Route::post('/settings/jobs', 'CompanySettingController@saveJob')->name('jobs.store');
Route::get('/settings/jobs/{job_id}', 'CompanySettingController@getJob')->name('jobs.show');

// system settings start
Route::get('/settings/system', 'SystemSettingController@index')->name('systemsettings');

// system settings end


//employee settings
Route::get('/settings/employee', 'EmployeeSettingController@index')->name('employeesettings');
Route::post('/settings/grades', 'EmployeeSettingController@saveGrade')->name('grades.store');
Route::get('/settings/grades/{grade_id}', 'EmployeeSettingController@getGrade')->name('grades.show');
Route::get('/settings/grades/delete/{grade_id}', 'EmployeeSettingController@deleteGrade')->name('grades.delete');
Route::post('/settings/qualifications', 'EmployeeSettingController@saveQualification')->name('qualifications.store');
Route::get('/settings/qualifications/{qualification_id}', 'EmployeeSettingController@getQualification')->name('qualifications.show');
Route::get('/settings/qualifications/delete/{qualification_id}', 'EmployeeSettingController@deleteQualification')->name('qualifications.delete');

//employee settings end
// attendance settings
Route::get('/settings/attendance', 'AttendanceSettingController@index')->name('attendancesettings');
Route::post('/settings/working_period', 'AttendanceSettingController@saveWorkingPeriod')->name('working_periods.store');
Route::get('/settings/working_period/{working_period_id}', 'AttendanceSettingController@getWorkingPeriod')->name('working_periods.show');
Route::get('/settings/working_period/delete/{working_period_id}', 'AttendanceSettingController@deleteWorkingPeriod')->name('working_periods.delete');
// attendance settings end
// executive view
Route::get('/people_analytics', 'HomeController@executiveView')->name('executive_view');
Route::get('/people_analytics_finance', 'HomeController@executiveViewFinance')->name('executive_view_finance');
Route::get('/people_analytics_second', 'HomeController@executiveViewSecond')->name('executive_view_second');
// end of executive view





/*************Payroll Module Start******************/
//fill in the update weekend form
Route::get('/edit-weekend_days', 'PayrollController@fill_weekend_form');
Route::get('/enablepay', 'PayrollController@enablepay');
Route::get('/payroll/endis', 'PayrollController@endis');


//ju
Route::get('tax_payable/{paxble}', 'PayrollController@tax_payable');

Route::get('/mypayslip/{payid}', 'PayrollController@create_payslip');
//update weekend form
Route::post('/update_weekend_days', 'PayrollController@update_weekend_form');

//Holiday Calendar
Route::get('/holiday-calendar', 'PayrollController@holiday_calendar');

//Add Holiday Form
Route::get('/add-holiday', 'PayrollController@add_holiday_form');

//Save Holiday Form
Route::post('/add-holiday', 'PayrollController@add_holiday');

//Edit Holiday form filling DB data
Route::get('/edit-holiday/{id}', array('uses' => 'PayrollController@fill_holiday_form'));

//Updating data
Route::post('/update-holiday', array('uses' => 'PayrollController@update_holiday_form'));

//List of holidays
Route::get('/holiday-list', 'PayrollController@holiday_list');

//Delete Holiday
Route::get('/delete_holiday/{id}', 'PayrollController@delete_holiday');

//Holiday Status Change
Route::post('/holiday_status_change', 'PayrollController@holiday_status_change');

//List of Employees to add or edit basic pay
Route::get('/basicpay-list', 'PayrollController@basicpay_list');

//Updating Payroll of employee by admin
Route::post('/basicpay-update', 'PayrollController@basicpay_update');

//Add Allowance Form
Route::get('/add-allowance', 'PayrollController@add_allowance_form');

//Save Allowance Form
Route::post('/add-allowance', 'PayrollController@add_allowance');

//Edit Allowance form filling DB data
Route::get('/edit-allowance/{id}', array('uses' => 'PayrollController@fill_allowance_form'));

//Updating Allowance
Route::post('/update-allowance', array('uses' => 'PayrollController@update_allowance_form'));

//List of Allowances
Route::get('/allowance-list', 'PayrollController@allowance_list');

//Delete Allowance
Route::get('/delete_allowance/{id}', 'PayrollController@delete_allowance');

//Allowance Status Change
Route::post('/allowance_status_change', 'PayrollController@allowance_status_change');

//List of Employees to add or edit Payroll
Route::get('/payroll-list', 'PayrollController@payroll_list');

Route::get('/payroll-list/{month_year}', 'PayrollController@payroll_list');
Route::get('/payrollchart', 'PayrollController@generate_chart');

//Get payroll details to save in admin panel
Route::get('/get-payroll/{id}', array('uses' => 'PayrollController@fill_payroll_form'));

//Get payroll details for employee to download
Route::get('/emp-payroll-list','PayrollController@emp_payroll_list');

//Get payroll details from table to show in admin panel
Route::get('/get-saved-payroll/{id}', array('uses' => 'PayrollController@fill_payroll_view'));
Route::get('/payroll/savecompupdate', array('uses' => 'PayrollController@update_comp_member'));

  
//Updating Payroll of employee by admin
Route::post('/payroll-update', 'PayrollController@payroll_update');

//Generating payslip by admin
Route::post('/issue_ps/{id}', 'PayrollController@create_ps');

//fill in the update CL form
Route::get('/edit-casual_leaves', 'PayrollController@fill_casual_leaves');

//update CL form
Route::post('/update_casual_leaves', 'PayrollController@update_casual_leaves');

//payslip list view of previous months for admin
Route::get('/view-previous-payslip', 'PayrollController@view_previous_payslip');

//fill in the update Payslip logo / watermark form
Route::get('/edit-payslip-details', 'PayrollController@fill_payslip_details');

//update CL form
Route::post('/update_payslip_details', 'PayrollController@update_payslip_details');

//List of all the expenses added by an employee
Route::get('/my-expenses', 'PayrollController@my_expenses_list');

//Add expense by an employee
Route::post('/add-expense', 'PayrollController@add_expense');

//Delete own expense added by the employee
Route::get('/delete_expense/{id}', 'PayrollController@delete_expense');

//Edit expense form filling DB data
Route::get('/edit-expense/{id}', array('uses' => 'PayrollController@fill_expense_form'));

//Updating expense
Route::post('/update-expense', array('uses' => 'PayrollController@update_expense'));

//List of all the expenses added by all the employees
Route::get('/employee-expenses', 'PayrollController@employee_expenses_list');

//Expense Status Change
Route::post('/update-expense-status', 'PayrollController@expense_status_change');



/*************Payroll Module End******************/

/***************Leave Management Module Start***********/

//Apply Leave Form
Route::get('/apply-leave', 'LeaveController@apply_leave_form');

//Get the number of working days within the date range selected while applying for casual leave
Route::post('/getavailleave', 'LeaveController@fnGetLeaves');

//Save Leave Form
Route::post('/apply-leave', 'LeaveController@add_leave');

//List of leaves of logged in employee
Route::get('/my-leaves', 'LeaveController@cl_list');

//Cancel Leave
Route::get('/cancel_leave/{id}', 'LeaveController@cancel_leave');

//Holiday Status Change
Route::post('/leave_status_change', 'LeaveController@leave_status_change');

//List of leaves applied by all employees
Route::get('/employee-leaves', 'LeaveController@all_cl_list');

//Leave Status Change
Route::post('/update-leave-status', 'LeaveController@status_change');
/***************Leave Management Module End***********/


/*************Attendance and Leave Module Start******************/

//Daily attendance individual view for admin and people manager
//Route::get('/view-daily-attendance/{id}', 'PayrollController@view_daily_attendance');
//Route::get('/my-attendance', 'PayrollController@view_daily_attendance');

//Daily attendance individual view of employee for admin and people manager
Route::post('/view-emp-daily-attendance', 'PayrollController@view_emp_daily_attendance');

//Calendar function for Daily attendance individual view of employee for admin and people manager without employee id
Route::get('/view-emp-daily-attendance', 'PayrollController@daily_attendance_list');

//
//Calendar function for Daily attendance individual view of employee for admin and people manager
Route::get('/view-emp-daily-attendance-calendar', 'PayrollController@view_emp_daily_attendance_calendar');

//Daily attendance calendar view for employee
Route::get('/view-daily-attendance', 'PayrollController@view_daily_attendance_calendar');

//calendar function for Daily attendance calendar view of employee
Route::get('/daily-attendance-calendar', 'PayrollController@daily_attendance_calendar');

//Daily attendance list view for admin all employees
//Route::get('/daily-attendance-list', 'PayrollController@daily_attendance_list');

//Daily attendance settings by admin
Route::get('/daily-attendance-settings', 'PayrollController@daily_attendance_settings');

//Daily attendance settings individual for edit by admin
Route::get('/edit-daily-attendance-settings/{id}', 'PayrollController@daily_attendance_settings_edit');

//Daily attendance settings new add by admin
Route::post('/add-daily-attendance-settings', 'PayrollController@daily_attendance_settings_add');

//Daily attendance settings to save by admin
Route::post('/update-daily-attendance-settings', array('uses' => 'PayrollController@daily_attendance_settings_update'));

//Daily attendance settings status change by admin
Route::post('/daily-attendance-settings-status-change', array('uses' => 'PayrollController@daily_attendance_settings_status_change'));

//Daily attendance list view of employees for people manager under him  
Route::get('/day-att-emp-list', 'PayrollController@day_att_emp_list');

//Delete Daily attendance settings
Route::get('/delete_daily_attendance_settings/{id}', 'PayrollController@delete_daily_attendance_settings');


//Updating daily attendance by employee
//Route::get('/daily-attendance', 'PayrollController@daily_attendance');

//Updating daily attendance in the database
Route::post('/daily-attendance-update', 'PayrollController@daily_attendance_update');

//Updating daily attendance in the database by people manager of employee
Route::post('/daily-attendance-emp-update', 'PayrollController@daily_attendance_emp_update');

//Saving daily attendance in the database by people manager of employee
Route::post('/daily-attendance-emp-save', 'PayrollController@daily_attendance_emp_save');

/*************Attendance and Leave Module End******************/

//Route::get("/test_pdf", 'PdfController@generate_pdf');

Route::get("/test_leave_calc", 'TestController@fnGetLeaves');


Route::get('/payroll-approval-settings', 'PayrollController@get_payroll_approval_settings');
Route::post('/update-payroll-approval-settings', 'PayrollController@update_payroll_approval_settings');
Route::get('/payroll_approval', 'PayrollController@payroll_approval_overview');
Route::get('/approve_or_reject_payroll', 'PayrollController@approve_or_reject_payroll');
Route::get('/allowance_status_change/{id}', 'PayrollController@allowance_status_change');

Route::get('/allowances', 'PayrollController@allowances');
Route::get('/specific_components', 'PayrollController@specific_components');
Route::post('/specific_components/add', 'PayrollController@add_specific_components');
Route::get('/delete_specific_component/{id}', 'PayrollController@delete_specific_component');
Route::post('/allowances/add', 'PayrollController@add_component');
Route::post('/allowances/edit', 'PayrollController@edit_component');

Route::get('/add-all-payroll', 'PayrollController@add_payroll_for_all_employees');
Route::get('/add-all-payslip', 'PayrollController@issue_payslip_for_all_employees');

Route::get('/disable_late', 'PayrollController@disable_late_charge');
Route::get('/enable_late', 'PayrollController@enable_late_charge');

Route::get('/disable_tax', 'PayrollController@disable_tax');
Route::get('/enable_tax', 'PayrollController@enable_tax');
Route::get('/generate_payroll_excel/{month_year}', 'PayrollController@generate_payroll_excel');

Route::get('/get_payroll_policy', 'PayrollController@get_payroll_policy');
Route::get('/payroll_month_settings/{when}', 'PayrollController@payroll_month_settings');
Route::get('/generate_payroll_excel/{month_year}', 'PayrollController@generate_payroll_excel');

Route::get('/get_payroll_policy', 'PayrollController@get_payroll_policy');
Route::get('/payrolltest', 'PayrollController@get_salary_components');

 Route::get('/payroll/clear/{monthyear}', 'PayrollController@clearpayroll');

Route::post('/addapplicant', 'EmployeeController@addapplicant');
Route::get('/payroll_month_settings/{when}/{percent}', 'PayrollController@payroll_month_settings');

Route::get('/payment/{month_year}', 'MoneywaveController@reinburse');
Route::get('/readprogress/{month_year}', 'MoneywaveController@readprogress');

Route::get('/create_wallet', 'MoneywaveController@createwallet');
Route::post('/fundwallet', 'MoneywaveController@fundwallet');
Route::get('/wallet', 'MoneywaveController@get_funding_history');
Route::get('/fixpayment', 'MoneywaveController@fixpayment');

Route::get('/validatetransaction/{auth}', 'MoneywaveController@validatetransaction');
Route::get('/retract_fund/{amount}', 'MoneywaveController@retract_fund');
Route::get('/success', 'MoneywaveController@validatetransaction');
Route::get('/mypayslip/{empnum}/{month}/{payrollid}', 'PayrollController@create_payslip');


Route::get('testrev', 'PayrollController@leaves');
 